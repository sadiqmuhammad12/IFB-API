-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 02, 2022 at 10:15 AM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fake_beggar`
--

-- --------------------------------------------------------

--
-- Table structure for table `beggar`
--

CREATE TABLE `beggar` (
  `id` int(10) NOT NULL,
  `full_name` varchar(250) NOT NULL,
  `cnic` varchar(250) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `address` varchar(250) NOT NULL,
  `phone_no` varchar(250) NOT NULL,
  `donation_amount` varchar(256) NOT NULL,
  `doner_name` varchar(256) NOT NULL,
  `description` varchar(256) NOT NULL,
  `img` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `beggar`
--

INSERT INTO `beggar` (`id`, `full_name`, `cnic`, `gender`, `address`, `phone_no`, `donation_amount`, `doner_name`, `description`, `img`) VALUES
(14, 'Amazing Pillow 2.0', '594389589489', 'Male', 'Mardan', '999', '9090', 'Naeem', '7854878578', 'ij.png'),
(15, 'Amazing Pillow 1.0', '594389589489', 'Male', 'Mardan', '999', '9090', 'Naeem', '7854878578', 'ij.png'),
(16, 'Amazing Pillow 1.0', '594389589489', 'Male', 'Mardan', '999', '9090', 'Naeem', '7854878578', 'ij.png');

-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--

CREATE TABLE `contact_us` (
  `id` int(11) NOT NULL,
  `full_name` varchar(256) NOT NULL,
  `email` varchar(256) NOT NULL,
  `city` varchar(256) NOT NULL,
  `comments` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contact_us`
--

INSERT INTO `contact_us` (`id`, `full_name`, `email`, `city`, `comments`) VALUES
(16, 'khalil', 'khalil@gmial.com', 'Darsamand', 'gsefduz rqrwe;oad jkleafd cuiefad'),
(17, 'khalil', 'khalil@gmial.com', 'Darsamand', 'gsefduz rqrwe;oad jkleafd cuiefad');

-- --------------------------------------------------------

--
-- Table structure for table `donation`
--

CREATE TABLE `donation` (
  `id` int(11) NOT NULL,
  `doner_id` int(10) NOT NULL,
  `beggar_cnic` varchar(256) DEFAULT NULL,
  `amount` varchar(256) NOT NULL,
  `doner_name` varchar(256) NOT NULL,
  `phone_no` varchar(256) NOT NULL,
  `gender` varchar(256) NOT NULL,
  `address` varchar(256) NOT NULL,
  `description` varchar(256) NOT NULL,
  `beggar_full_name` varchar(256) NOT NULL,
  `name` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `donation`
--

INSERT INTO `donation` (`id`, `doner_id`, `beggar_cnic`, `amount`, `doner_name`, `phone_no`, `gender`, `address`, `description`, `beggar_full_name`, `name`) VALUES
(134, 46, '785757378345', '900000', 'Javid', '04457645775', 'Male', 'Hangu', 'fhayusfueauh', 'Naeem Ullah', 'd.PNG'),
(135, 46, '785757378345', '900000', 'inam', '04457645775', 'Male', 'Hangu', 'fhayusfueauh', 'Naeem Ullah', 'de.PNG'),
(136, 47, '785757378345', '900000', 'inam', '04457645775', 'Male', 'Hangu', 'fhayusfueauh', 'Naeem Ullah', 'create.PNG'),
(137, 47, '889977', '900000', 'inam', '04457645775', 'Male', 'Hangu', 'fhayusfueauh', 'Naeem Ullah', 'create.PNG');

-- --------------------------------------------------------

--
-- Table structure for table `image`
--

CREATE TABLE `image` (
  `id` int(11) NOT NULL,
  `doner_id` int(10) NOT NULL,
  `name` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `image`
--

INSERT INTO `image` (`id`, `doner_id`, `name`) VALUES
(11, 46, 'de.PNG');

-- --------------------------------------------------------

--
-- Table structure for table `slogan`
--

CREATE TABLE `slogan` (
  `id` int(11) NOT NULL,
  `name` varchar(256) NOT NULL,
  `qoute` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `slogan`
--

INSERT INTO `slogan` (`id`, `name`, `qoute`) VALUES
(1, 'create.PNG', 'This is for testing'),
(2, 'd.PNG', 'This image ........................'),
(4, 'de.PNG', 'This image ........................');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `id` int(11) NOT NULL,
  `full_name` varchar(256) NOT NULL,
  `email` varchar(256) NOT NULL,
  `passwords` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`id`, `full_name`, `email`, `passwords`) VALUES
(1, 'Naeem', 'naeem123', 'naeem123'),
(2, 'Karim', 'karim123', 'karim123'),
(3, 'javid', 'javid123', 'javid123'),
(4, 'fazal', 'fazal123', 'fazal123'),
(5, 'shakir', 'shakir123', 'shakir123');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) NOT NULL,
  `username` varchar(256) NOT NULL,
  `email` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `verification_code` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `verification_code`) VALUES
(46, 'javid', 'javid@gmail.com', '$2y$10$YAz9Ls6qGy.Gjjre3AdRdOefHqir5KRcJyIwhrLyUE1WQN0x65w8C', ''),
(47, 'Hamid', 'hamid@gmail.com', '$2y$10$Im3RjnnM5u/T.R20d9hCCe6PUeNgkistAeiZ/mMhwy3IfSn2rkkN6', ''),
(48, 'zakir', 'zakir@gmail.com', '$2y$10$9u4e8vfQLXtlngH5jUt1veyNTy6OG9u7UHY6ogeaCtUfpeHHLzcHq', '');

-- --------------------------------------------------------

--
-- Table structure for table `volunteer`
--

CREATE TABLE `volunteer` (
  `id` int(11) NOT NULL,
  `full_name` varchar(250) NOT NULL,
  `cnic` varchar(250) NOT NULL,
  `gender` varchar(250) NOT NULL,
  `address` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `volunteer`
--

INSERT INTO `volunteer` (`id`, `full_name`, `cnic`, `gender`, `address`) VALUES
(1, 'Ibrahim', '14102-05387673', 'Male', 'Malakand'),
(2, 'Danyal', '14101-9567864-1', 'Male', 'Swat'),
(4, 'Nayla', '', 'Female', 'Charsada');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `beggar`
--
ALTER TABLE `beggar`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_us`
--
ALTER TABLE `contact_us`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `donation`
--
ALTER TABLE `donation`
  ADD PRIMARY KEY (`id`),
  ADD KEY `TEST` (`doner_id`);

--
-- Indexes for table `image`
--
ALTER TABLE `image`
  ADD PRIMARY KEY (`id`),
  ADD KEY `doner_id` (`doner_id`);

--
-- Indexes for table `slogan`
--
ALTER TABLE `slogan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `volunteer`
--
ALTER TABLE `volunteer`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `beggar`
--
ALTER TABLE `beggar`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `contact_us`
--
ALTER TABLE `contact_us`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `donation`
--
ALTER TABLE `donation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=138;

--
-- AUTO_INCREMENT for table `image`
--
ALTER TABLE `image`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `slogan`
--
ALTER TABLE `slogan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `volunteer`
--
ALTER TABLE `volunteer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `donation`
--
ALTER TABLE `donation`
  ADD CONSTRAINT `TEST` FOREIGN KEY (`doner_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `image`
--
ALTER TABLE `image`
  ADD CONSTRAINT `image_ibfk_1` FOREIGN KEY (`doner_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
